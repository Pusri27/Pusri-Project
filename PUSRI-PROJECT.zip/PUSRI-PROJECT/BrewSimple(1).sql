-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 17, 2025 at 07:05 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `BrewSimple`
--

-- --------------------------------------------------------

--
-- Table structure for table `Admin`
--

CREATE TABLE `Admin` (
  `Admin_ID` int(11) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Admin`
--

INSERT INTO `Admin` (`Admin_ID`, `Username`, `Password`) VALUES
(1, 'admin', '$2y$10$m/EJhRckK.wCzAD9IUDoDec9DNi5FUebhCzIVYK/4lblVc6O8BcDa');

-- --------------------------------------------------------

--
-- Table structure for table `Customer`
--

CREATE TABLE `Customer` (
  `Cust_ID` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Phone` varchar(15) DEFAULT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Customer`
--

INSERT INTO `Customer` (`Cust_ID`, `Name`, `Email`, `Phone`, `Password`) VALUES
(1, 'Pusri Ananda', 'pusri.ananda@email.com', '081234567890', '$2y$10$OFbksNw6G2CmjWGn6t0N.e3cHpNViyinxTvvbgkNVYA3DPzecNsbm'),
(2, 'Ruben Ben', 'ruben.ben@email.com', '081234567891', ''),
(3, 'Nabil Bil', 'nabil.bil@email.com', '081234567892', ''),
(4, 'Wilson Son', 'wilson.son@email.com', '081234567893', ''),
(5, 'Gabriel Biel', 'gabriel.biel@email.com', '081234567894', ''),
(29, 'Daniel Niel', 'daniel@email.com', '081234567895', '$2y$10$YmLLcyYchouSlyDQNV1OH.j.6Lsrsdb5eMfaD2GacVQ3zMQCgJ1mq'),
(30, 'Theodore', 'theodore@email.com', '085678924034', '$2y$10$MKFHc4lZe901Ba/NCTqFLeKxuRCwXxfttIvDOk8AGQJ.OLLkQe7h2'),
(35, 'handal', 'handal@yahoo.com', '09123456789', '$2y$10$cU7YRoOrtQomzYFXLO7tkufSr/DgzIWLJuvHMhVfjZOEB6l.JONeu'),
(38, 'anandahandal', 'ananda@icloud.com', '08987654321', '$2y$10$bOScHeW3V6HG9p782M5ztuR9n2.vbrda.rGI60pEtOdK7bgksC7xO');

-- --------------------------------------------------------

--
-- Table structure for table `MenuCategory`
--

CREATE TABLE `MenuCategory` (
  `Category_ID` int(11) NOT NULL,
  `CategoryName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `MenuCategory`
--

INSERT INTO `MenuCategory` (`Category_ID`, `CategoryName`) VALUES
(1, 'Espresso Drinks'),
(2, 'Brewed Coffee'),
(3, 'Tea'),
(4, 'Pastries'),
(5, 'Sandwiches'),
(14, 'Gorengann');

-- --------------------------------------------------------

--
-- Table structure for table `MenuItem`
--

CREATE TABLE `MenuItem` (
  `Item_ID` int(11) NOT NULL,
  `ItemName` varchar(100) NOT NULL,
  `Price` decimal(10,2) NOT NULL,
  `Category_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `MenuItem`
--

INSERT INTO `MenuItem` (`Item_ID`, `ItemName`, `Price`, `Category_ID`) VALUES
(1, 'Espresso', 15.00, 1),
(2, 'Latte', 20.00, 1),
(3, 'Drip Coffee', 10.00, 2),
(4, 'Green Tea', 12.00, 3),
(5, 'Croissant', 15.00, 4),
(6, 'Ham Sandwich', 25.00, 5),
(15, 'Latte Vanila', 100.00, 2),
(18, 'Martabak Goreng', 15.00, 14);

-- --------------------------------------------------------

--
-- Table structure for table `OrderDetail`
--

CREATE TABLE `OrderDetail` (
  `Order_ID` int(11) NOT NULL,
  `Item_ID` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `ItemPrice` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `OrderDetail`
--

INSERT INTO `OrderDetail` (`Order_ID`, `Item_ID`, `Quantity`, `ItemPrice`) VALUES
(1, 1, 1, 15.00),
(1, 5, 2, 15.00),
(2, 2, 1, 20.00),
(2, 3, 1, 10.00),
(3, 4, 1, 12.00),
(4, 1, 2, 15.00),
(16, 1, 1, 15.00),
(17, 1, 1, 15.00),
(20, 6, 2, 25.00),
(21, 6, 1, 25.00),
(22, 15, 1, 100.00),
(23, 15, 1, 100.00),
(26, 1, 1, 15.00),
(27, 1, 1, 15.00),
(28, 1, 1, 15.00),
(29, 15, 1, 100.00),
(30, 5, 1, 15.00),
(30, 6, 1, 25.00),
(31, 5, 1, 15.00),
(32, 1, 1, 15.00),
(32, 2, 1, 20.00),
(33, 15, 1, 100.00),
(34, 5, 1, 15.00),
(35, 2, 1, 20.00),
(36, 2, 1, 20.00),
(37, 1, 1, 15.00),
(38, 1, 2, 15.00),
(39, 1, 1, 15.00),
(40, 2, 1, 20.00);

-- --------------------------------------------------------

--
-- Table structure for table `Orders`
--

CREATE TABLE `Orders` (
  `Order_ID` int(11) NOT NULL,
  `OrderDate` date NOT NULL,
  `TotalPrice` decimal(10,2) NOT NULL,
  `Status` varchar(20) NOT NULL DEFAULT 'Pending',
  `Cust_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Orders`
--

INSERT INTO `Orders` (`Order_ID`, `OrderDate`, `TotalPrice`, `Status`, `Cust_ID`) VALUES
(1, '2025-04-01', 45.00, 'Completed', 1),
(2, '2025-04-02', 30.00, 'Pending', 2),
(3, '2025-04-03', 27.00, 'Completed', 3),
(4, '2025-04-04', 40.00, 'In Progress', 1),
(5, '2025-04-05', 18.00, 'Pending', 4),
(16, '2025-04-11', 15.00, 'Completed', 1),
(17, '2025-04-11', 15.00, 'Completed', 1),
(20, '2025-04-21', 50.00, 'Completed', 1),
(21, '2025-04-21', 25.00, 'Completed', 1),
(22, '2025-04-21', 100.00, 'Completed', 1),
(23, '2025-04-22', 100.00, 'Completed', 1),
(24, '2025-04-22', 0.00, 'Paid', 1),
(25, '2025-04-22', 0.00, 'Pending', 1),
(26, '2025-04-23', 15.00, 'Pending', 1),
(27, '2025-04-23', 15.00, 'Pending', 1),
(28, '2025-04-23', 15.00, 'Completed', 1),
(29, '2025-04-23', 100.00, 'Completed', 1),
(30, '2025-04-23', 40.00, 'Pending', 1),
(31, '2025-04-23', 15.00, 'Pending', 1),
(32, '2025-04-23', 35.00, 'Paid', 1),
(33, '2025-04-23', 100.00, 'Pending', 1),
(34, '2025-04-23', 15.00, 'Paid', 1),
(35, '2025-04-24', 20.00, 'Paid', 1),
(36, '2025-04-28', 20.00, 'Paid', 1),
(37, '2025-04-29', 15.00, 'Paid', 1),
(38, '2025-04-30', 30.00, 'Paid', 1),
(39, '2025-06-17', 15.00, 'Paid', 1),
(40, '2025-06-17', 20.00, 'Paid', 1);

-- --------------------------------------------------------

--
-- Table structure for table `Payment`
--

CREATE TABLE `Payment` (
  `Payment_ID` int(11) NOT NULL,
  `Order_ID` int(11) DEFAULT NULL,
  `Method` varchar(20) NOT NULL,
  `Amount` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Payment`
--

INSERT INTO `Payment` (`Payment_ID`, `Order_ID`, `Method`, `Amount`) VALUES
(1, 1, 'Cash', 45.00),
(2, 2, 'Online', 30.00),
(3, 3, 'Cash', 27.00),
(4, 4, 'Online', 40.00),
(5, 5, 'Cash', 18.00),
(6, 16, 'Cash', 15.00),
(7, 17, 'Cash', 15.00),
(10, 20, 'Cash', 50.00),
(11, 21, 'Online', 25.00),
(12, 22, 'Cash', 100.00),
(13, 23, 'Online', 100.00),
(14, 28, 'Cash', 15.00),
(15, 29, 'Cash', 100.00),
(16, 32, 'Card', 35.00),
(17, 34, 'Cash', 15.00),
(18, 35, 'Cash', 20.00),
(19, 36, 'Cash', 20.00),
(20, 37, 'Cash', 15.00),
(21, 38, 'Card', 30.00),
(22, 24, 'Cash', 0.00),
(23, 39, 'Card', 15.00),
(24, 40, 'Card', 20.00);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Admin`
--
ALTER TABLE `Admin`
  ADD PRIMARY KEY (`Admin_ID`),
  ADD UNIQUE KEY `Username` (`Username`);

--
-- Indexes for table `Customer`
--
ALTER TABLE `Customer`
  ADD PRIMARY KEY (`Cust_ID`);

--
-- Indexes for table `MenuCategory`
--
ALTER TABLE `MenuCategory`
  ADD PRIMARY KEY (`Category_ID`);

--
-- Indexes for table `MenuItem`
--
ALTER TABLE `MenuItem`
  ADD PRIMARY KEY (`Item_ID`),
  ADD KEY `Category_ID` (`Category_ID`);

--
-- Indexes for table `OrderDetail`
--
ALTER TABLE `OrderDetail`
  ADD PRIMARY KEY (`Order_ID`,`Item_ID`),
  ADD KEY `Item_ID` (`Item_ID`);

--
-- Indexes for table `Orders`
--
ALTER TABLE `Orders`
  ADD PRIMARY KEY (`Order_ID`),
  ADD KEY `Cust_ID` (`Cust_ID`);

--
-- Indexes for table `Payment`
--
ALTER TABLE `Payment`
  ADD PRIMARY KEY (`Payment_ID`),
  ADD KEY `Order_ID` (`Order_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Admin`
--
ALTER TABLE `Admin`
  MODIFY `Admin_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `Customer`
--
ALTER TABLE `Customer`
  MODIFY `Cust_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `MenuCategory`
--
ALTER TABLE `MenuCategory`
  MODIFY `Category_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `MenuItem`
--
ALTER TABLE `MenuItem`
  MODIFY `Item_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `Orders`
--
ALTER TABLE `Orders`
  MODIFY `Order_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `Payment`
--
ALTER TABLE `Payment`
  MODIFY `Payment_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `MenuItem`
--
ALTER TABLE `MenuItem`
  ADD CONSTRAINT `menuitem_ibfk_1` FOREIGN KEY (`Category_ID`) REFERENCES `MenuCategory` (`Category_ID`);

--
-- Constraints for table `OrderDetail`
--
ALTER TABLE `OrderDetail`
  ADD CONSTRAINT `orderdetail_ibfk_1` FOREIGN KEY (`Order_ID`) REFERENCES `Orders` (`Order_ID`),
  ADD CONSTRAINT `orderdetail_ibfk_2` FOREIGN KEY (`Item_ID`) REFERENCES `MenuItem` (`Item_ID`);

--
-- Constraints for table `Orders`
--
ALTER TABLE `Orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`Cust_ID`) REFERENCES `Customer` (`Cust_ID`);

--
-- Constraints for table `Payment`
--
ALTER TABLE `Payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`Order_ID`) REFERENCES `Orders` (`Order_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
